# Question 1: Blocks World

state = {
    "ArmEmpty",
    "Clear(A)", "Clear(B)", "Clear(C)", "Clear(D)",
    "OnTable(A)", "OnTable(B)", "OnTable(C)", "OnTable(D)"
}

def show_state(title):
    print("\\n" + title)
    order = [
        "ArmEmpty",
        "Clear(A)", "Clear(B)", "Clear(C)", "Clear(D)",
        "On(A,C)", "On(D,B)",
        "OnTable(A)", "OnTable(B)", "OnTable(C)", "OnTable(D)"
    ]
    for item in order:
        if item in state:
            print(item)

def pickup(block):
    state.remove("ArmEmpty")
    state.remove("Clear(" + block + ")")
    state.remove("OnTable(" + block + ")")
    state.add("Holding(" + block + ")")
    print("Action: PICKUP(" + block + ")")

def stack(block, base):
    state.remove("Holding(" + block + ")")
    state.remove("Clear(" + base + ")")
    state.add("On(" + block + "," + base + ")")
    state.add("Clear(" + block + ")")
    state.add("ArmEmpty")
    print("Action: STACK(" + block + ", " + base + ")")

show_state("Initial State:")

print("\\nGoal Stack / Action Sequence:")
pickup("A")
stack("A", "C")
pickup("D")
stack("D", "B")

show_state("Final State:")

if "On(A,C)" in state and "On(D,B)" in state:
    print("\\nBoth goal conditions have been achieved.")
